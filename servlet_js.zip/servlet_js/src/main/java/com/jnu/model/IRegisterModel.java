package com.jnu.model;

public interface IRegisterModel {
    boolean register(String userName, String password, String idpassword);
}
