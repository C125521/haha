package com.jnu.model;

public interface ILoginModel
{
    boolean login(String userName, String password);
}
