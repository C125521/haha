package com.jnu.service;

public interface IRegisterService {
    boolean register(String userName, String password, String idpassword);
}
