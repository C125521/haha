package com.jnu.service;

public interface ILoginService {
    boolean login(String userName, String password);
}
