package com.jnu.service;

public interface IPersonalService {
    boolean update(String now_userName, String userName, String password, String name, String sno, String gender, String per_class, String IDnumber, String age, String addr, String mor_up, String eve_sleep, String bestfood, String fav_place, String faav_idol, String fav_book, String hobby);
}
