<template>
  <div id="aaa">
  <div class="loginform">
    <h1 align="center">欢迎注册</h1>
    <form action="http://localhost:8080/demo2_war_exploded/login" method="post">
      <table border="0" align="center">
        <tr><td>用户名:</td><td><input id="userName" name="userName" type="text"></td></tr>
        <tr><td>密 码: </td><td><input id="password" name="password" type="password"></td></tr>
        <tr><td> <el-button type="success" round v-on:click="Loginon">去登录</el-button></td></tr>
      </table>
    </form>
  </div>
  </div>
</template>

<script>
export default {
  name: "Register",

methods:{
Loginon: function (){
  this.$message({
    message:"请登录!",
    type:'success'
  });
  this.$router.push({name:"login",params:{"userName":this.userName}});
}
}
}

</script>

<style scoped>
#aaa{
  background: url("imgs/2.jpg");
  width :100%;
  height:100%;
  position: fixed;
  background-size: cover;
  /*添加动画*/
  animation-name: register-animation;
  /*动画执行时间*/
  animation-duration: 10s;
  /*动画延时时间*/
  animation-delay: 2s;
  /*动画开始时间 无限*/
  animation-iteration-count: infinite;
  /*动画循环播放*/
  animation-play-state: running;
}
/*添加动画属性*/
@keyframes register-animation {
  0%{background:url("imgs/2.jpg");
    background-size: cover;
  }
  35%{background:url("imgs/1.jpg");
    background-size: cover;
  }
  60%{background:url("imgs/3.jpg");
    background-size: cover;
  }
  100%{background:url("imgs/4.jpg");
    background-size: cover;
  }
}
.loginform{
  background: rgba(255 , 255 , 255 ,0.1);
  width: 300px;
  margin:150px auto;
}
</style>
