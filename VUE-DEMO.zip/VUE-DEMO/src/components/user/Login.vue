<template>
  <div id="ccc">
    <div class="loginform">
      <h1 align="center">欢迎登录</h1>
      <form action="http://localhost:8080/demo2_war_exploded/login" method="post">
        <table border="0" align="center">
          <tr>
            <td>用 户 名:</td>
            <td><input type="text" v-model="userName"></td>
          </tr>
          <tr>
            <td>密 码:</td>
            <td><input v-model="password" type="password"></td>
          </tr>
          <tr>
            <td>确认密码:</td>
            <td><input v-model="password" type="password"></td>
          </tr>
          <tr>
            <td>
              <el-button type="success" round v-on:click="onLogin">登录</el-button>
            </td>
            <td>
              <el-button type="danger" round v-on:click="onRegister">注册</el-button>
            </td>
          </tr>
        </table>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  name: "Login",
  data: function () {
    return {
      userName: "",
      password: ""
    }
  },
  methods: {
    onLogin() {
      this.$http.get('http://localhost:8888/doLogin', {
        params: {
          "userName": this.userName,
          "password": this.password
        }
      }).then(function (res) {
        alert("登录状态：" + res.body);
        document.write(res.body);
      }, function () {
        console.log('请求失败处理');
      });
      this.$router.push('Home');
    },
    onRegister() {
      this.$message({
        message: "请注册！",
        type: 'danger'
      })
      this.$router.push('Register');
    }
  }
}
</script>
<style scoped>
#ccc {
  background: url("imgs/2.jpg");
  width: 100%;
  height: 100%;
  position: fixed;
  background-size: cover;
  /*添加动画*/
  animation-name: login-animation;
  /*动画执行时间*/
  animation-duration: 10s;
  /*动画延时时间*/
  animation-delay: 2s;
  /*动画开始时间 无限*/
  animation-iteration-count: infinite;
  /*动画循环播放*/
  animation-play-state: running;
}

/*添加动画属性*/
@keyframes login-animation {
  0% {
    background: url("imgs/2.jpg");
    background-size: cover;
  }
  35% {
    background: url("imgs/1.jpg");
    background-size: cover;
  }
  60% {
    background: url("imgs/3.jpg");
    background-size: cover;
  }
  100% {
    background: url("imgs/4.jpg");
    background-size: cover;
  }
}

.loginform {
  background: rgba(255, 255, 255, 0.1);
  width: 300px;
  margin: 150px auto;
}
</style>
