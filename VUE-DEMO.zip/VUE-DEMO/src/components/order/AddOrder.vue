<template>
  <div><h1>添加订单</h1></div>
</template>

<script>
export default {
  name: "AddOrder"
}
</script>

<style scoped>

</style>
