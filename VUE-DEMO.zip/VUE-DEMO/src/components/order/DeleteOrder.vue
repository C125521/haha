<template>

</template>

<script>
export default {
  name: "Delete"
}
</script>

<style scoped>

</style>
