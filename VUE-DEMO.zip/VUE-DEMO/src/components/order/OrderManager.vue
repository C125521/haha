<template>
  <div><h1>添加订单</h1>
    <route-view>主页面</route-view>
  </div>
</template>

<script>
export default {
  name: "OrderManager"
}
</script>

<style scoped>

</style>
